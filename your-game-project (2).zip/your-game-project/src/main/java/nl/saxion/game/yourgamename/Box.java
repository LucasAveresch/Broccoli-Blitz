package nl.saxion.game.yourgamename;

public class Box {
    float width;
    float height;
}
