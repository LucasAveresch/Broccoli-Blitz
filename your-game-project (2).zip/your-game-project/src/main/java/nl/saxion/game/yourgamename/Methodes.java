package nl.saxion.game.yourgamename;

import nl.saxion.gameapp.GameApp;

public class Methodes {



    public static void john(){


    System.out.println("Poepers");
    }
}
